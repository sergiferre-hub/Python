#1
print ("Posa el numero de l'altura del quadrat:")
y = (input())

print ("L'area del quadrat es :", int(y) * int(y))


#2
print ("Posa dos numeros:")
x = int(input())
y = int(input())

print ("La suma es :", x + y)
print ("La resta es :", x - y)
print ("La multiplicacio es :", x * y)
print ("La divisio es :", x / y)


#3
print ("Posa 3 paraules per fer una frase:")
a = input()
b = input()
c = input()

print ("La frase es:", a, b, c)


#4
x = float(input("Posa un numero amb coma:"))
y = float(input("Posa un altre numero amb coma:"))

print ("La suma es:", int(x + y))
print ("La resta es:", int(x - y))